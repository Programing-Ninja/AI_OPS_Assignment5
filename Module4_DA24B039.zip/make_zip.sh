#!/usr/bin/env bash
# Builds Module4_DA24B039.zip. Usage: bash make_zip.sh
set -euo pipefail
cd "$(dirname "$0")"
ZIP=Module4_DA24B039.zip
rm -f "$ZIP"
zip -q "$ZIP" \
  REPORT.pdf report/REPORT.tex report/make_figures.py report/fig_loadtest.pdf README.md AI_DISCLOSURE.md requirements.txt eta_data.py load_test.py make_zip.sh \
  partA/eta_app.py partA/test_eta_app.py partA/mutation_check.py partA/run_loadtest.sh partA/server_cpu.sh \
  partA/loadtest_results.json partA/loadtest_extended.json partA/loadtest_batch1.json partA/loadtest_batch100.json \
  partA/loadtest_2workers_uvicorn.json partA/loadtest_2workers_gunicorn.json partA/loadtest_console.txt \
  partA/server_cpu.txt partA/nagle_note.txt partA/pytest_output.txt partA/mutation_output.txt \
  partB/eta_mlflow.py partB/test_gate.py partB/shadow_eta.py partB/gate_output.txt partB/shadow_output.txt \
  partC/eta_ray.py partC/verify_ray.py partC/verify_output.txt \
  partD/smoke_eta.py partD/smoke_output.txt
unzip -l "$ZIP"
