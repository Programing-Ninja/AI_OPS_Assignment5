"""Draws report/fig_loadtest.pdf from the Part A load-test JSON files."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
A = ROOT / "partA"
OUT = ROOT / "report" / "fig_loadtest.pdf"

BLUE, ORANGE, AQUA, BLUE_DARK = "#2a78d6", "#eb6834", "#1baf7a", "#184f95"
INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8984", "#e4e3df"

def load(name):
    return json.loads((A / name).read_text())

one = load("loadtest_results.json") + load("loadtest_extended.json")
uv2 = load("loadtest_2workers_uvicorn.json")
gu2 = load("loadtest_2workers_gunicorn.json")
col = lambda rows, k: [r[k] for r in rows]

plt.rcParams.update({"font.family": "serif", "font.size": 8.5, "axes.edgecolor": MUTED, "axes.labelcolor": INK2,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.linewidth": 0.6, "xtick.major.width": 0.6,
                     "ytick.major.width": 0.6})
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.0, 2.6), constrained_layout=True)

def style(ax, ylabel):
    ax.set_xscale("log", base=2)
    ax.set_xticks([1, 2, 4, 8, 16, 32, 64]); ax.set_xticklabels(["1", "2", "4", "8", "16", "32", "64"])
    ax.set_xlabel("concurrent clients N")
    ax.set_ylabel(ylabel)
    ax.grid(True, axis="y", color=GRID, linewidth=0.6); ax.set_axisbelow(True)

series = [("1 worker", one, BLUE, "o"), ("uvicorn, 2 workers", uv2, ORANGE, "s"),
          ("gunicorn, 2 workers", gu2, AQUA, "^")]
for label, rows, c, m in series:
    ax1.plot(col(rows, "concurrency"), col(rows, "rps"), color=c, marker=m, markersize=4.5, linewidth=1.6,
             markeredgecolor="white", markeredgewidth=0.8, label=label, zorder=3)
style(ax1, "throughput (requests/s)")
ax1.set_ylim(0, 1400)
ax1.set_title("(a) Throughput saturates at N = 2-4", loc="left", fontsize=9, color=INK)
ax1.legend(frameon=False, fontsize=7.5, loc="lower right", labelcolor=INK2)

N, X = col(one, "concurrency"), col(one, "rps")
ax2.axhline(80, color=MUTED, linewidth=0.9, linestyle=(0, (4, 3)), zorder=1)
ax2.text(1.05, 71, "SLO: p95 = 80 ms", color=INK2, fontsize=7.5)
ax2.plot(N, col(one, "p50_ms"), color=BLUE, marker="o", markersize=4.5, linewidth=1.6,
         markeredgecolor="white", markeredgewidth=0.8, label="p50 (measured)", zorder=3)
ax2.plot(N, col(one, "p95_ms"), color=BLUE_DARK, marker="s", markersize=4.5, linewidth=1.6,
         markeredgecolor="white", markeredgewidth=0.8, label="p95 (measured)", zorder=3)
ax2.plot(N, [1000 * n / x for n, x in zip(N, X)], color=INK, linewidth=1.1, linestyle=(0, (1, 1.5)),
         label="Little's Law N/X (predicts p50)", zorder=4)
style(ax2, "latency (ms)")
ax2.set_ylim(0, 150)
ax2.set_title("(b) 1 worker: past the knee it is queueing", loc="left", fontsize=9, color=INK)
ax2.legend(frameon=False, fontsize=7.5, loc="upper left", labelcolor=INK2)

fig.savefig(OUT)
fig.savefig(OUT.with_suffix(".png"), dpi=150)
print(f"wrote {OUT}")
